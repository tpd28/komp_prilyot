# Перевірка всіх сценаріїв прототипу після змін.
# Запуск: python3 tests/perevirka.py   (потрібен Python Playwright з Chromium)
import os, sys
from playwright.sync_api import sync_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
URL = 'file://' + os.path.join(ROOT, 'dist', 'index.html')
fails = []
def check(name, ok, info=''):
    print(('OK   ' if ok else 'FAIL ') + name + (f'  [{info}]' if info else ''))
    if not ok: fails.append(name)

def fresh(pg, h=''):
    pg.goto('about:blank'); pg.goto(URL + (('#' + h) if h else '')); pg.wait_for_timeout(700)

def cit_login(pg):
    fresh(pg, 'zayavnyk'); pg.click('[data-apply] >> nth=0'); pg.click('[data-auth=key]'); pg.wait_for_timeout(1800); pg.click('.demo summary')

with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page(viewport={'width': 1366, 'height': 900})
    errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))

    # 1. Презентація і переходи між ролями
    fresh(pg)
    check('Презентація відкривається першою', pg.locator('#v-intro').is_visible())
    for proto, want in [('zayavnyk', 'Матеріальна допомога'), ('uo-order', 'Виберіть послугу'), ('rv-dept', 'Поточні задачі')]:
        fresh(pg); pg.click(f'#v-intro [data-proto="{proto}"]'); pg.wait_for_timeout(1200)
        check(f'Перехід з презентації: {proto}', want in pg.locator('h1:visible').first.inner_text())
        pg.click('.demo summary'); pg.click('.demo [data-proto="intro"]'); pg.wait_for_timeout(1200)
        check(f'Повернення на презентацію з {proto}', pg.locator('#v-intro').is_visible())

    # 2. Заявник: повне подання з прикладом → 5 заяв
    cit_login(pg)
    for _ in range(12):
        if pg.evaluate('view') != 'form': break
        pg.click('#dm-fill'); pg.wait_for_timeout(150); pg.click('#bNext'); pg.wait_for_timeout(150)
    check('Заявник: на підписі 5 заяв', pg.locator('#signBody .doc li').count() == 5)
    pg.click('#signBtn'); pg.click('[data-sign] >> nth=0'); pg.wait_for_timeout(1700); pg.click('#mod .btn'); pg.wait_for_timeout(200)
    check('Заявник: заяви в «Замовлених послугах»', '10' in pg.inner_text('#ordGrid .g-total'))

    # 3. Заявник: «Не можу вказати точну адресу»
    cit_login(pg)
    while pg.evaluate('step') != 'event': pg.click('#dm-fill'); pg.click('#bNext'); pg.wait_for_timeout(100)
    check('Без адреси: чекбокс прихований без поранення/загибелі', not pg.locator('#e-noaddr').is_visible())
    for e in ['injury', 'death', 'housing']: pg.check('#ev-' + e)
    check('Без адреси: чекбокс з’являється (усі три події)', pg.locator('#e-noaddr').is_visible())
    pg.check('#e-noaddr')
    check('Без адреси: житло зняте і приховане', not pg.locator('#ev-housing').is_visible() and not pg.is_checked('#ev-housing'))
    check('Без адреси: поле опису замість адреси', pg.locator('#e-desc').is_visible() and not pg.locator('#e-dist').is_visible())
    pg.uncheck('#e-noaddr'); check('Без адреси: житло повертається', pg.locator('#ev-housing').is_visible())

    # 4. Уповноважена особа: подання заяви за заявника
    fresh(pg, 'uo-order'); pg.click('[data-start]'); pg.click('.demo summary')
    pg.click('#dm-fill'); pg.wait_for_timeout(200)
    check('УО: чекбокс «Не можу вказати точну адресу»', pg.locator('#e-noaddr').is_visible())
    for st in range(5):
        pg.click('#dm-fill'); pg.wait_for_timeout(1200 if st == 4 else 100); pg.click('#bNext')
    pg.click('#doneBtn'); pg.click('#mod .btn'); pg.wait_for_timeout(200)
    check('УО: заяви в «Замовлених послугах»', '10' in pg.inner_text('#ordGrid .g-total'))

    # 5. Розгляд: зміна суми з обґрунтуванням, рішення, КЕП
    fresh(pg, 'rv-dept')
    pg.locator('#taskGrid tbody tr', has_text='МД-05112026-188').first.click(); pg.click('#take'); pg.click('#bNext'); pg.check('input[name=dec][value=ok]')
    check('Розгляд: сума підставляється', pg.input_value('#okSum') != '', pg.input_value('#okSum'))
    pg.fill('#okSum', ''); pg.type('#okSum', '10000'); pg.click('#bNext')
    check('Розгляд: без причини зміни суми не пускає', len(pg.locator('#s-result .err').all_inner_texts()) > 0)
    pg.fill('#okWhy', 'За довідкою медичного закладу ушкодження легкі'); pg.click('#bNext'); pg.wait_for_timeout(200)
    pg.click('#signBtn'); pg.locator('#kKey').set_input_files({'name': 'k.pfx', 'mimeType': 'application/octet-stream', 'buffer': b'x'})
    pg.fill('#kPw', '1'); pg.click('#kGo'); pg.wait_for_timeout(1600); pg.click('#mod .btn')
    pg.locator('#taskGrid tbody tr', has_text='МД-05112026-188').first.click(); pg.wait_for_timeout(200)
    check('Розгляд: рішення з новою сумою', '10 000 (передбачено' in pg.inner_text('#s-info'))

    check('Без помилок JavaScript', not errs, '; '.join(errs)[:200])
    b.close()

print('\nУСЕ ПРАЦЮЄ' if not fails else f'\nНЕ ПРОЙШЛО: {len(fails)}')
sys.exit(1 if fails else 0)
