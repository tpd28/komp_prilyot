(function(){
const IC={
 refresh:'<svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 4v7h-7"/></svg>',
 cols:'<svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linejoin="round"><rect x="4" y="4" width="6" height="16" rx="1"/><rect x="14" y="4" width="6" height="16" rx="1"/></svg>',
 rows:'<svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linejoin="round"><rect x="4" y="4" width="16" height="16" rx="1.5"/><path d="M4 9.5h16M4 14.5h16"/></svg>',
 filter:'<svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M4 7h16M7 12h10M10 17h4"/></svg>',
 search:'<svg aria-hidden="true" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><circle cx="11" cy="11" r="6.5"/><path d="m20 20-4-4"/></svg>',
 caret:'<svg aria-hidden="true" width="10" height="10" viewBox="0 0 10 10"><path d="M1 3h8L5 8z" fill="currentColor"/></svg>'
};
const esc=s=>String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const PILL={'Подано':'peach','У роботі':'peach','Очікується оплата':'peach','В роботі':'work','Статус не задано':'grey','Виконано':'ok','Схвалено':'ok','Відмовлено':'rej','Потребує доопрацювання':'rework','Подано (нова)':'new','Подано (з доопрацюванням)':'new'};
const pill=t=>`<span class="st ${PILL[t]||'grey'}">${esc(t)}</span>`;
const parseD=s=>{const m=String(s).match(/(\d{2})\.(\d{2})\.(\d{4})(?:\s+(\d{2}):(\d{2}))?/);return m?+(m[3]+m[2]+m[1]+(m[4]||'00')+(m[5]||'00')):0;};
let uid=0;
function Grid(root,cfg){
  const id='g'+(++uid);
  const S={hidden:new Set(cfg.cols.filter(c=>c.hide).map(c=>c.k)),dens:'',status:'',sort:cfg.sort?{...cfg.sort}:null,fk:cfg.cols[0].k,fv:'',q:''};
  const col=k=>cfg.cols.find(c=>c.k===k);
  const txt=(c,r)=>c.text?c.text(r):(r[c.k]==null?'':String(r[c.k]));
  const key=(c,r)=>c.date?parseD(txt(c,r)):txt(c,r).toLowerCase();
  const sortable=cfg.cols.filter(c=>c.date);
  root.innerHTML=`<div class="g-bar">
    <button type="button" class="g-btn" data-g="refresh">${IC.refresh}Оновити</button>
    <div class="g-pop"><button type="button" class="g-btn" data-g="cols" aria-expanded="false" aria-controls="${id}-cols">${IC.cols}Колонки</button><div class="g-menu" id="${id}-cols" hidden></div></div>
    <div class="g-pop"><button type="button" class="g-btn" data-g="dens" aria-expanded="false" aria-controls="${id}-dens">${IC.rows}Рядки</button><div class="g-menu" id="${id}-dens" hidden></div></div>
    ${cfg.status?`<div class="g-pop"><button type="button" class="g-btn" data-g="status" aria-expanded="false" aria-controls="${id}-status">${esc(cfg.status.label)} <b class="g-sv">Усі</b>${IC.caret}</button><div class="g-menu" id="${id}-status" hidden></div></div>`:''}
    ${sortable.length&&cfg.sortMenu!==false?`<div class="g-pop"><button type="button" class="g-btn" data-g="sort" aria-expanded="false" aria-controls="${id}-sort">За датою ${IC.caret}</button><div class="g-menu" id="${id}-sort" hidden></div></div>`:''}
    ${cfg.filters?`<button type="button" class="g-btn" data-g="filter" aria-expanded="false">${IC.filter}Фільтри<span class="g-fc" hidden>1</span></button>`:''}
    ${cfg.search?`<label class="g-search">${IC.search}<input type="text" placeholder="Пошук" aria-label="Пошук у таблиці"></label>`:''}
  </div>
  ${cfg.filters?`<div class="g-fpanel" hidden>
    <div class="fld"><label for="${id}-fk">Колонка</label><select id="${id}-fk" class="g-fk">${cfg.cols.map(c=>`<option value="${c.k}">${esc(c.label)}</option>`).join('')}</select></div>
    <div class="fld"><label for="${id}-op">Оператор</label><select id="${id}-op" disabled><option>містить</option></select></div>
    <div class="fld"><label for="${id}-fv">Значення</label><input id="${id}-fv" type="text" class="g-fv" placeholder="Значення фільтра"></div>
    <button type="button" class="lnk" data-g="fclear">Очистити</button></div>`:''}
  <div class="g-wrap"><table class="g-tbl"><thead></thead><tbody></tbody></table></div>
  <p class="g-empty" hidden>${esc(cfg.empty||'Записів не знайдено')}</p>
  <p class="g-total"></p>`;
  const q=s=>root.querySelector(s);
  let current=[];
  function data(){
    let rows=cfg.rows().slice();
    if(S.status) rows=rows.filter(r=>cfg.status.get(r)===S.status);
    if(S.q){ const v=S.q.toLowerCase(); rows=rows.filter(r=>cfg.cols.some(c=>txt(c,r).toLowerCase().includes(v))); }
    if(S.fv){ const c=col(S.fk), v=S.fv.toLowerCase(); rows=rows.filter(r=>txt(c,r).toLowerCase().includes(v)); }
    if(S.sort){ const c=col(S.sort.k); rows.sort((a,b)=>{const x=key(c,a),y=key(c,b);return (typeof x==='number'?x-y:String(x).localeCompare(String(y),'uk'))*S.sort.dir;}); }
    return rows;
  }
  function menus(){
    q(`#${id}-cols`).innerHTML='<p class="g-mh">Показувати колонки</p>'+cfg.cols.map(c=>`<label class="g-mi"><input type="checkbox" data-col="${c.k}"${S.hidden.has(c.k)?'':' checked'}>${esc(c.label)}</label>`).join('')+'<button type="button" class="g-mi" data-g="allcols">Показати всі</button>';
    q(`#${id}-dens`).innerHTML=[['dense','Компактні'],['','Стандартні'],['tall','Збільшені']].map(([v,l])=>`<button type="button" class="g-mi${S.dens===v?' on':''}" data-dens="${v}">${l}</button>`).join('');
    if(cfg.status) q(`#${id}-status`).innerHTML=['',...cfg.status.options].map(o=>`<button type="button" class="g-mi${S.status===o?' on':''}" data-sv="${esc(o)}">${o?esc(o):'Усі'}</button>`).join('');
    if(q(`#${id}-sort`)){ const dk=(S.sort&&col(S.sort.k).date)?S.sort.k:sortable[0].k;
      q(`#${id}-sort`).innerHTML=sortable.map(c=>[[1,'спочатку старіші'],[-1,'спочатку новіші']].map(([d,l])=>`<button type="button" class="g-mi${S.sort&&S.sort.k===c.k&&S.sort.dir===d?' on':''}" data-sort="${c.k}" data-dir="${d}">${esc(c.label)}: ${l}</button>`).join('')).join(''); }
  }
  function render(){
    const vis=cfg.cols.filter(c=>!S.hidden.has(c.k)); current=data();
    const t=q('.g-tbl'); t.className='g-tbl'+(S.dens?' '+S.dens:'');
    t.tHead.innerHTML='<tr>'+vis.map(c=>`<th scope="col"${c.w?` style="min-width:${c.w}px"`:''}><button type="button" class="g-th" data-sk="${c.k}">${esc(c.label)}${S.sort&&S.sort.k===c.k?`<span class="g-arr" aria-label="${S.sort.dir>0?'за зростанням':'за спаданням'}">${S.sort.dir>0?'↑':'↓'}</span>`:''}</button></th>`).join('')+'</tr>';
    t.tBodies[0].innerHTML=current.map((r,i)=>`<tr class="${cfg.rowClass?cfg.rowClass(r):''}"${cfg.onRow?` data-ri="${i}" tabindex="0"`:''}>${vis.map(c=>{const v=txt(c,r);return `<td title="${esc(v)}"${c.w?` style="min-width:${c.w}px"`:''}>${c.pill?pill(v):c.render?c.render(r):esc(v)}</td>`;}).join('')}</tr>`).join('');
    q('.g-empty').hidden=current.length>0;
    q('.g-total').textContent='Всього записів: '+current.length;
    if(cfg.status) q('.g-sv').textContent=S.status||'Усі';
    const fc=q('.g-fc'); if(fc) fc.hidden=!S.fv;
    menus();
  }
  function closeAll(except){ root.querySelectorAll('.g-menu').forEach(m=>{ if(m!==except){ m.hidden=true; const b=root.querySelector(`[aria-controls="${m.id}"]`); b&&b.setAttribute('aria-expanded','false'); } }); }
  root.addEventListener('click',e=>{
    const b=e.target.closest('[data-g]');
    if(b){ const a=b.dataset.g;
      if(a==='refresh'){ render(); return; }
      if(['cols','dens','status','sort'].includes(a)){ const m=q(`#${id}-${a}`); const open=m.hidden; closeAll(m); m.hidden=!open; b.setAttribute('aria-expanded',String(open)); return; }
      if(a==='filter'){ const p=q('.g-fpanel'); p.hidden=!p.hidden; b.setAttribute('aria-expanded',String(!p.hidden)); if(!p.hidden) q('.g-fv').focus(); return; }
      if(a==='fclear'){ S.fv=''; q('.g-fv').value=''; render(); return; }
      if(a==='allcols'){ S.hidden.clear(); render(); return; } }
    const d=e.target.closest('[data-dens]'); if(d){ S.dens=d.dataset.dens; closeAll(); render(); return; }
    const sv=e.target.closest('[data-sv]'); if(sv){ S.status=sv.dataset.sv; closeAll(); render(); return; }
    const so=e.target.closest('[data-sort]'); if(so){ S.sort={k:so.dataset.sort,dir:+so.dataset.dir}; closeAll(); render(); return; }
    const th=e.target.closest('[data-sk]'); if(th){ const k=th.dataset.sk; S.sort={k,dir:S.sort&&S.sort.k===k?-S.sort.dir:1}; render(); return; }
    const tr=e.target.closest('tr[data-ri]'); if(tr&&cfg.onRow) cfg.onRow(current[+tr.dataset.ri]);
  });
  root.addEventListener('change',e=>{ const c=e.target.closest('[data-col]'); if(c){ const k=c.dataset.col; if(c.checked) S.hidden.delete(k); else { if(cfg.cols.length-S.hidden.size<=1){ c.checked=true; return; } S.hidden.add(k); } render(); }
    if(e.target.classList.contains('g-fk')){ S.fk=e.target.value; render(); } });
  root.addEventListener('input',e=>{ if(e.target.closest('.g-search')){ S.q=e.target.value.trim(); render(); } if(e.target.classList.contains('g-fv')){ S.fv=e.target.value.trim(); render(); } });
  root.addEventListener('keydown',e=>{ if(e.key==='Enter'){ const tr=e.target.closest('tr[data-ri]'); if(tr&&cfg.onRow) cfg.onRow(current[+tr.dataset.ri]); } if(e.key==='Escape') closeAll(); });
  document.addEventListener('click',e=>{ if(!root.contains(e.target)||!e.target.closest('.g-pop')) closeAll(); });
  render();
  return {refresh:render,state:S};
}
Grid.pill=pill;
document.addEventListener('click',e=>{ const h=e.target.closest('[data-hash]'); if(h){ e.preventDefault(); e.stopImmediatePropagation(); location.hash=h.dataset.hash; } },true);
window.Grid=Grid;
/* бокове меню */
document.addEventListener('click',e=>{ const g=e.target.closest('.s-grp'); if(!g) return; const sub=document.getElementById(g.getAttribute('aria-controls')); const ex=g.getAttribute('aria-expanded')==='true'; g.setAttribute('aria-expanded',String(!ex)); sub.hidden=ex; });
window.setMenu=function(k){ document.querySelectorAll('.side2 [data-m]').forEach(x=>{ const on=x.dataset.m===k; x.classList.toggle('on',on); if(on) x.setAttribute('aria-current','page'); else x.removeAttribute('aria-current'); }); };
/* вибір послуги */
document.addEventListener('input',e=>{ const s=e.target.closest('.ch-search input'); if(!s) return; const v=s.value.trim().toLowerCase(), wrap=s.closest('.ch-search').parentElement, list=wrap.querySelector('.ch-list'); let n=0; list.querySelectorAll('.ch-row').forEach(r=>{ const ok=!v||r.textContent.toLowerCase().includes(v); r.hidden=!ok; if(ok) n++; }); const em=wrap.querySelector('.ch-empty'); if(em) em.hidden=n>0; });
})();
