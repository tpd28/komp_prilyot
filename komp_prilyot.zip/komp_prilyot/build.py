# Збирання прототипів послуги «Матеріальна допомога постраждалим від обстрілів».
# Запуск: python3 build.py  → результат у dist/
import re,base64,os
ROOT=os.path.dirname(os.path.abspath(__file__)); os.chdir(os.path.join(ROOT,'src'))
OUT=os.path.join(ROOT,'dist')
CSS=open('kabinet.css').read(); GJS=open('grid.js').read()
def must(s,a,b,cnt=1):
    assert a in s, 'MISSING: '+a[:100]; return s.replace(a,b,cnt)
def rsub(s,pat,rep,flags=re.S):
    n=re.subn(pat,lambda m:rep,s,count=1,flags=flags); assert n[1]==1,'NO MATCH: '+pat[:80]; return n[0]
I={'inbox':'<svg aria-hidden="true" width="22" height="22" viewBox="0 0 24 24" fill="currentColor"><path d="M4 3h16a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H8l-5 4V5a2 2 0 0 1 1-2zm3 5v2h10V8H7zm0 4v2h7v-2H7z"/></svg>',
 'tasks':'<svg aria-hidden="true" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="7" width="18" height="13" rx="2"/><path d="M9 7V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>',
 'svc':'<svg aria-hidden="true" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 6h10M11 12h10M11 18h10"/><path d="m3 6 1.5 1.5L7 5M3 12l1.5 1.5L7 11"/><path d="M3.5 18h3"/></svg>',
 'docs':'<svg aria-hidden="true" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 3H6a1 1 0 0 0-1 1v16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V8z"/><path d="M14 3v5h5M9 14l2 2 4-4"/></svg>',
 'regs':'<svg aria-hidden="true" width="22" height="22" viewBox="0 0 24 24" fill="currentColor"><rect x="3" y="4" width="18" height="4" rx="1"/><rect x="3" y="10" width="18" height="4" rx="1"/><rect x="3" y="16" width="18" height="4" rx="1"/></svg>',
 'me':'<svg aria-hidden="true" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 3h9l4 4v14H6z"/><path d="M9 11h7M9 15h7M9 7h4"/></svg>'}
PLUS='<svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>'
def b(t,bid=None): return f'<span class="s-b"{f" id=\"{bid}\"" if bid else ""}>{t}</span>' if t else ''
def top(label,icon,attr,badge='',bid=None): return f'<a href="#" class="s-top" {attr}>{I[icon]}<span>{label}</span>{b(badge,bid)}</a>'
def it(label,attr,m=None,badge='',bid=None): return f'<a href="#" class="s-it" {attr}{f" data-m=\"{m}\"" if m else ""}><span>{label}</span>{b(badge,bid)}</a>'
def grp(label,icon,gid,items): return f'<button type="button" class="s-top s-grp" aria-expanded="true" aria-controls="{gid}">{I[icon]}<span>{label}</span><span class="s-car" aria-hidden="true"></span></button><div class="s-sub" id="{gid}">{"".join(items)}</div>'
def side(kind):
    S='data-soon'
    if kind=='cit':
        parts=[top('Вхідні повідомлення','inbox',S,'3'),
          grp('Задачі','tasks','sg-t',[it('Мої задачі',S)]),
          grp('Мої послуги','svc','sg-s',[it('Замовлені послуги','data-nav="orders"','orders','5','ordCount'),it('Чернетки','data-nav="drafts"','drafts')]),
          top('Отримані документи','docs',S),top('Відомості про мене','me',S)]
    else:
        uo=kind=='uo'
        parts=[f'<a href="#" class="s-order" {"data-nav=\"order\"" if uo else "data-hash=\"uo-order\""}>{PLUS}Замовити послугу</a>',top('Вхідні повідомлення','inbox',S,'99+'),
          grp('Задачі','tasks','sg-t',[it('Мої задачі','data-hash="rv-mine"' if uo else 'data-nav="mine"',None if uo else 'mine'),it('Очікує підпису',S),
             it('Задачі відділу','data-hash="rv-dept"' if uo else 'data-nav="dept"',None if uo else 'dept','4',None if uo else 'deptCnt'),it('Архів моїх задач',S),it('Архів задач відділу',S)]),
          grp('Мої послуги','svc','sg-s',[it('Замовлені послуги','data-nav="orders"' if uo else 'data-hash="uo-orders"','orders' if uo else None),it('Чернетки',S)]),
          top('Отримані документи','docs',S,'68'),top('Реєстри','regs',S),top('Відомості про мене','me',S)]
    return '<aside class="side2" aria-label="Меню кабінету">\n    '+'\n    '.join(parts)+'\n  </aside>'
DOCI='<svg aria-hidden="true" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M14 3H6a1 1 0 0 0-1 1v16a1 1 0 0 0 1 1h6"/><path d="M14 3v5h5v4M8 9h4M8 13h5M8 17h3"/><circle cx="17.5" cy="17.5" r="3.5"/><path d="M17.5 16v3M16 17.5h3"/></svg>'
CHEV='<svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="m9 6 6 6-6 6"/></svg>'
SRCH='<svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#1B2433" stroke-width="2.4" stroke-linecap="round"><circle cx="11" cy="11" r="6.5"/><path d="m20 20-4-4"/></svg>'
OUR='Матеріальна допомога особам, що опинились в складних життєвих обставинах внаслідок обстрілів'
def chooser(vid,start_attr,others):
    rows=[f'<button type="button" class="ch-row" {start_attr}>{DOCI}<span class="t">{OUR}</span>{CHEV}</button>']+[f'<button type="button" class="ch-row" data-soon>{DOCI}<span class="t">{o}</span>{CHEV}</button>' for o in others]
    return f'''<div id="{vid}" hidden>
    <h1 class="ph1">Виберіть послугу</h1>
    <label class="ch-search">{SRCH}<input type="text" placeholder="Почніть вводити назву послуги" aria-label="Пошук послуги"></label>
    <div class="ch-list">{"".join(rows)}</div>
    <p class="ch-empty" hidden>Послуг за цим запитом не знайдено.</p>
  </div>'''
def common(s,font_old,font_new):
    s=must(s,font_old,font_new)
    s=must(s,'</style>',CSS+'</style>')
    i=s.index('<script>'); s=s[:i]+'<script>\n'+GJS+'\n</script>\n'+s[i:]
    return s

# ================= ЗАЯВНИК =================
cit=open('zayavnyk.html').read().split('\n<script>\n(function(){')[0]
cit=common(cit,'family=Unbounded:wght@600&','family=Unbounded:wght@600;700&')
cit=rsub(cit,r'<aside class="side" aria-label="Меню кабінету">.*?</aside>',side('cit'))
cit=rsub(cit,r'  <!-- Замовлені послуги / чернетки -->\n  <div id="v-orders" hidden>.*?\n  </div>\n',
 '  '+chooser('v-choose','data-startc',['Подання заяви на отримання документа в БТІ','Створення читацького квитка','Оздоровлення та відпочинок дітей віком від 7 до 18 років','Одноразова матеріальна допомога малозабезпеченим киянам','Часткове відшкодування вартості незалежних джерел електричної енергії','Запит до архіву'])+
 '\n\n  <!-- Замовлені послуги / чернетки -->\n  <div id="v-orders" hidden>\n    <h1 class="ph1" id="ordTitle">Замовлені послуги</h1>\n    <div id="ordGrid"></div>\n    <div id="drGrid" hidden></div>\n  </div>\n')
cit=must(cit,"$('#v-form').hidden=v!=='form'; $('#v-sign').hidden=v!=='sign'; $('#v-orders').hidden=!(v==='orders'||v==='drafts');",
 "$('#v-form').hidden=v!=='form'; $('#v-sign').hidden=v!=='sign'; $('#v-orders').hidden=!(v==='orders'||v==='drafts'); $('#v-choose').hidden=v!=='choose'; document.querySelector('#v-cab .col').classList.toggle('wide',v==='orders'||v==='drafts');")
cit=must(cit,"$('#m-orders').classList.toggle('on',v==='orders');\n  $('#m-drafts').classList.toggle('on',v==='form'||v==='sign'||v==='drafts');","setMenu({orders:'orders',drafts:'drafts',form:'drafts',sign:'drafts'}[v]||'');")
cit=must(cit,"if(['orders','drafts','form'].includes(t)&&!logged)","if(['orders','drafts','form','choose'].includes(t)&&!logged)")
cit=must(cit,"let pending='form';","let pending='form';\ndocument.addEventListener('click',e=>{ if(e.target.closest('[data-startc]')){ step='applicant'; go('form'); } });")
cit=must(cit,"svc:x.svc,date:today}));","svc:x.svc,date:today+' '+new Date().toTimeString().slice(0,5)}));")
cit=rsub(cit,r"function buildOrders\(v\)\{.*?\n\}\n",r'''const BASE_ORD=[
 {no:'КП2-Т30-ЗС-404-101126',svc:'Подання заяви на отримання документа в БТІ',st:'Подано',date:'10.11.2026 15:40'},
 {no:'bib-31-26',svc:'Створення читацького квитка',st:'Виконано',date:'10.11.2026 13:18'},
 {no:'57-101126',svc:'Оздоровлення та відпочинок дітей віком від 7 до 18 років',st:'Статус не задано',date:'10.11.2026 11:38'},
 {no:'КП1-Т10-КВ-356-021126',svc:'Подання заяви на отримання документа в БТІ',st:'Очікується оплата',date:'02.11.2026 14:46'},
 {no:'ТП-Т5-БК-316-281026',svc:'Подання заяви на отримання документа в БТІ',st:'У роботі',date:'28.10.2026 23:51'}];
let ordG=null, drG=null;
function buildOrders(v){
  $('#ordTitle').textContent=v==='drafts'?'Чернетки':'Замовлені послуги';
  $('#ordGrid').hidden=v==='drafts'; $('#drGrid').hidden=v!=='drafts';
  if(v==='drafts'){
    const d=new Date(), dd=`${String(d.getDate()).padStart(2,'0')}.${String(d.getMonth()+1).padStart(2,'0')}.${d.getFullYear()}`;
    if(drG) drG.refresh(); else drG=Grid($('#drGrid'),{cols:[{k:'svc',label:'Послуга',w:380},{k:'date',label:'Дата створення',date:1,w:150},{k:'act',label:'Дія',text:()=>'Продовжити заповнення',render:()=>'<span style="color:var(--btn);font-weight:600">Продовжити заповнення</span>'}],rows:()=>[{svc:'Матеріальна допомога особам, що опинились в складних життєвих обставинах внаслідок обстрілів',date:dd}],sortMenu:false,onRow:()=>go('form')});
    return; }
  if(ordG) ordG.refresh(); else ordG=Grid($('#ordGrid'),{cols:[{k:'no',label:'Номер заяви',w:170},{k:'svc',label:'Послуга',w:340},{k:'st',label:'Статус',pill:1},{k:'date',label:'Дата замовлення',date:1,w:150}],
    rows:()=>[...orders.map(o=>({...o,st:'Подано'})),...BASE_ORD],status:{label:'За статусом',options:['Подано','У роботі','Очікується оплата','Виконано','Статус не задано'],get:r=>r.st},sort:{k:'date',dir:-1},sortMenu:false});
}
''')

cit=must(cit,'<button type="button" id="dm-reset">Почати спочатку</button>','<button type="button" id="dm-fill">Заповнити крок прикладом</button>\n    <button type="button" id="dm-reset">Почати спочатку</button>')
cit=must(cit,"/* ---------- Старт ---------- */",r"""/* ---------- Заповнення прикладом ---------- */
function fillDemo(){
  if(view!=='form'){ modal('<h2 id="modT" style="font-size:16px">Відкрийте заяву</h2><p style="font-size:14px">Приклад заповнює поточний крок заяви.</p><button type="button" class="btn" data-close>Зрозуміло</button>'); return; }
  const sec=$('#s-'+step);
  const setR=(n,v)=>{ const x=$(`input[name="${n}"][value="${v}"]`); if(x) x.checked=true; };
  const setDate=(el,d,m,y)=>{ const [a,b,c]=$$('input,select',el); a.value=d; b.value=m; c.value=y; };
  const setPib=(el,l,f,m)=>{ el.querySelector('.p-l').value=l; el.querySelector('.p-f').value=f; el.querySelector('.p-m').value=m; };
  if(step==='applicant'){ $('#a-ph').value='+380501234567'; }
  if(step==='event'){ ['injury','death','housing'].forEach(e=>$('#ev-'+e).checked=true); renderStepper();
    setDate($('#e-date'),'12','10','2026'); const d=$('#e-dist'); d.value='Деснянський'; d.dispatchEvent(new Event('change')); $('#e-str').value='вул. Закревського'; $('#e-house').value='19'; $('#e-flat').value='45'; }
  if(step==='injury'){ setR('inj','self'); cond(); $('#i-s-deg').value='Середньої тяжкості'; }
  if(step==='death'){ $('#d-rel').value='spouse'; setPib($('#d-fio'),'Коваленко','Іван','Петрович'); $('#d-cser').value='І-ТВ'; $('#d-cnum').value='654321'; setDate($('#d-date'),'12','10','2026'); }
  if(step==='housing'){ setR('h_own','owner'); cond(); setR('h_cat','many'); cond(); setR('h_move','yes'); cond(); setR('h_other','no'); cond(); setR('h_mon','yes'); cond(); ['h_mc1','h_mc2','h_mc3'].forEach(n=>setR(n,'no')); }
  if(step==='payment'){ $('#p-iban').value='UA21 3223 1300 0002 6007 2335 6600 1'; }
  if(step==='docs'){ passDiia=true; $('#diiaBtn').hidden=true; $('#diiaOk').hidden=false; $('#passUp').hidden=true; }
  if(step==='terms'){ setR('t1','1'); setR('t2','1'); termsGate(); }
  for(let k=0;k<3;k++){ cond();
    $$('.reg',sec).forEach(r=>{ if(!hiddenIn(r,sec)){ const g=r.querySelector('[data-group]'); if(g&&!val(g.dataset.group).length) setR(g.dataset.group,'kyiv'); } });
    cond();
    $$('.up[data-req]',sec).forEach(u=>{ if(!hiddenIn(u,sec)&&!u._files.length){ u._files.push({name:'dokument_'+(u.dataset.label.split(' ')[0]||'').toLowerCase()+'.pdf',size:184320}); drawFiles(u); } }); }
  $$('select').forEach(x=>x.classList.toggle('empty',!x.value)); $$('.bad').forEach(clearBad); cond();
}
$('#dm-fill').addEventListener('click',fillDemo);

/* ---------- Старт ---------- */""")

# --- Презентація рішення (перша сторінка)
cit=must(cit,'<div class="pub" id="v-service" hidden>', open('prezentatsiia.html').read()+'\n<div class="pub" id="v-service" hidden>')
cit=cit.replace('</style>', open('prezentatsiia.css').read()+'</style>',1)
cit=must(cit,"const pubV=['service','auth'];","const pubV=['service','auth','intro']; document.body.classList.toggle('introm',v==='intro');")
cit=must(cit,"\ngo('service');\n","\n{ const h=location.hash.slice(1); go(h===''||h==='intro'?'intro':'service'); }\ndocument.addEventListener('click',e=>{ const s=e.target.closest('[data-scroll]'); if(s){ const t=document.getElementById(s.dataset.scroll); t&&t.scrollIntoView({behavior:'smooth',block:'start'}); } });\n")
cit=must(cit,'data-proto="rv" style','data-proto="rv-dept" style')
INTRO_BTN='<button type="button" data-proto="intro">← Презентація рішення</button>\n    '
cit=must(cit,'<button type="button" data-proto="uo" style',INTRO_BTN+'<button type="button" data-proto="uo" style')

# ================= УПОВНОВАЖЕНА ОСОБА =================
uo=open('uo.html').read()
uo=common(uo,'family=Onest:wght@400;500;600;700&display=swap','family=Onest:wght@400;500;600;700&family=Unbounded:wght@600;700&display=swap')
uo=must(uo,'<nav class="mainnav" aria-label="Основна навігація"><a href="#" data-soon>Міські послуги</a><a href="#" data-soon>Часті питання</a></nav>','<nav class="mainnav" aria-label="Основна навігація"><a href="#" data-soon>Міські послуги</a><a href="#" data-soon>Новини</a><a href="#" data-soon>Часті запитання</a></nav>')
uo=rsub(uo,r'<aside class="side uo" aria-label="Меню кабінету">.*?</aside>',side('uo'))
uo=rsub(uo,r'<!-- Мої задачі -->\n  <div id="v-tasks" hidden>.*?\n  </div>\n\n','<!-- Задачі -->\n  <div id="v-tasks" hidden>\n    <h1 class="ph1" id="tasksTitle">Мої задачі</h1>\n    <div id="taskGrid"></div>\n  </div>\n\n')
uo=rsub(uo,r'<div id="v-order" hidden>.*?\n  </div>\n\n  <!-- Форма -->',chooser('v-order','data-start',['Заява на участь в аукціоні на сезонну торгівлю','Реєстрація заявки на отримання гуманітарної допомоги','Додати довірену особу','Деактивувати довірену особу','Заява на участь у ярмарку','Додати права уповноваженій особі','Видалити права уповноваженої особи','Розірвання договору','Визначення переможця'])+'\n\n  <!-- Форма -->')
uo=rsub(uo,r'<!-- Реєстр -->\n  <div id="v-reg" hidden>.*?\n  </div>\n','<!-- Замовлені послуги -->\n  <div id="v-orders" hidden>\n    <h1 class="ph1">Замовлені послуги</h1>\n    <div id="ordGrid"></div>\n  </div>\n')
uo=must(uo,"['tasks','order','form','sign','reg'].forEach(x=>$('#v-'+x).hidden=v!==x);","['order','form','sign','orders'].forEach(x=>$('#v-'+x).hidden=v!==x); $('#v-tasks').hidden=!(v==='tasks'||v==='dept'); document.querySelector('#v-cab .col').classList.toggle('wide',['tasks','dept','orders'].includes(v));")
uo=must(uo,"$('#m-tasks').classList.toggle('on',v==='tasks'); $('#m-reg').classList.toggle('on',v==='reg');","setMenu(v);")
uo=rsub(uo,r"  if\(v==='reg'\) \$\('#regRows'\).*?join\(''\);\n","  if(v==='orders') ordGrid(); if(v==='tasks'||v==='dept') taskGrid(v);\n")
uo=must(uo,'data-nav="reg">Перейти до реєстру</button>','data-nav="orders">До замовлених послуг</button>')
uo=must(uo,"svc:x.svc,date:today}));","svc:x.svc,date:today+' '+new Date().toTimeString().slice(0,5)}));")
uo=rsub(uo,r"\$\('#oSearch'\)\.addEventListener\('submit'.*?\n","")
uo=must(uo,"/* ---------- Навігація ---------- */",r'''/* ---------- Реєстри ---------- */
const PROC='Матеріальна допомога через обстріли';
const UO_ORD=[
 {no:'МД-03112026-101',ap:'Коваленко Ірина Олексіївна',svc:'Допомога у зв\'язку з пораненням',ch:'Уповноважена особа',st:'В роботі',date:'03.11.2026 10:43'},
 {no:'МД-03112026-103',ap:'Коваленко Ірина Олексіївна',svc:'Допомога у зв\'язку із загибеллю члена родини',ch:'Уповноважена особа',st:'В роботі',date:'03.11.2026 10:43'},
 {no:'МД-28102026-061',ap:'Гончаренко Тетяна Василівна',svc:'Одноразова допомога за пошкоджене житло (10 000 грн)',ch:'Уповноважена особа',st:'Схвалено',date:'28.10.2026 11:20'},
 {no:'МД-10102026-102',ap:'Мельник Василь Іванович',svc:'Одноразова допомога за пошкоджене житло (10 000 грн)',ch:'Уповноважена особа',st:'Відмовлено',date:'10.10.2026 12:31'}];
const UO_TASKS=[
 {no:'МД-04112026-155',task:'Доопрацювання заяви',proc:PROC,ap:'Мельник Петро Ігорович',st:'Потребує доопрацювання',ex:'Петренко О. В.',rec:'04.11.2026 12:10',due:'04.12.2026 12:10',dist:'Деснянський'},
 {no:'МД-07112026-212',task:'Видача рішення заявнику',proc:PROC,ap:'Савчук Ганна Миколаївна',st:'Схвалено',ex:'Петренко О. В.',rec:'07.11.2026 09:30',due:'14.11.2026 09:30',dist:'Деснянський'},
 {no:'МД-10112026-251',task:'Доопрацювання заяви',proc:PROC,ap:'Гончаренко Тетяна Василівна',st:'Потребує доопрацювання',ex:'Петренко О. В.',rec:'10.11.2026 16:45',due:'10.12.2026 16:45',dist:'Деснянський'},
 {no:'МД-09112026-240',task:'Доопрацювання заяви',proc:PROC,ap:'Лисенко Андрій Петрович',st:'Потребує доопрацювання',ex:'Гнатюк Т. В.',rec:'09.11.2026 15:05',due:'09.12.2026 15:05',dist:'Деснянський'},
 {no:'А883-29102026',task:'Розгляд запиту до архіву',proc:'Запит в архів',ap:'Допоможенко В. В.',st:'Подано',ex:'',rec:'29.10.2026 16:15',due:'',dist:'Деснянський'}];
let _og=null,_tg=null,_tmode='tasks';
function ordGrid(){ if(_og){_og.refresh();return;}
  _og=Grid($('#ordGrid'),{cols:[{k:'no',label:'Номер заяви',w:170},{k:'svc',label:'Послуга',w:300},{k:'ap',label:'Заявник',w:200},{k:'ch',label:'Канал подання',hide:1},{k:'st',label:'Статус',pill:1},{k:'date',label:'Дата замовлення',date:1,w:150}],
   rows:()=>[...reg.map(r=>({...r,ch:'Уповноважена особа',st:'Подано'})),...UO_ORD],status:{label:'За статусом',options:['Подано','В роботі','Схвалено','Відмовлено','Потребує доопрацювання'],get:r=>r.st},sort:{k:'date',dir:-1},sortMenu:false,
   onRow:r=>modal(`<h2 id="modT" style="font-size:17px">Заява № ${esc(r.no)}</h2><p style="font-size:14px;text-align:left">${esc(r.svc)}<br>Заявник: ${esc(r.ap)}<br>Статус: ${esc(r.st)} · ${esc(r.date)}</p><p style="font-size:13px;color:var(--muted)">Картку замовленої послуги в прототипі не реалізовано.</p><button type="button" class="btn" data-close>Зрозуміло</button>`)}); }
function taskGrid(v){ _tmode=v; $('#tasksTitle').textContent=v==='dept'?'Поточні задачі мого відділу':'Мої задачі'; if(_tg){_tg.refresh();return;}
  _tg=Grid($('#taskGrid'),{cols:[{k:'no',label:'Номер запиту',w:140},{k:'task',label:'Задача',w:170},{k:'proc',label:'Назва процесу',w:180},{k:'ap',label:'Заявник',w:150},{k:'type',label:'Тип заявника',text:()=>'Фізична особа',w:120},{k:'dep',label:'Підрозділ',text:()=>'Уповноважені особи Деснянської РДА',w:150},{k:'ex',label:'Виконавець',w:130},{k:'rec',label:'Дата надходження',date:1,w:140},{k:'due',label:'Кінцева дата',date:1,w:140},{k:'dist',label:'Район'},{k:'st',label:'Статус',hide:1}],
   rows:()=>UO_TASKS.filter(t=>_tmode==='dept'||t.ex==='Петренко О. В.'),rowClass:r=>r.st==='Потребує доопрацювання'?'hl':'',sort:{k:'rec',dir:-1},filters:true,search:true,
   onRow:r=>modal(`<h2 id="modT" style="font-size:17px">${esc(r.task)} № ${esc(r.no)}</h2><p style="font-size:14px">Заявник: ${esc(r.ap)}. Відкриття цієї задачі в прототипі не реалізовано.</p><button type="button" class="btn" data-close>Зрозуміло</button>`)}); }

/* ---------- Навігація ---------- */''')

uo=must(uo,'<a href="#" class="logo" data-nav="tasks"','<a href="#" class="logo" data-hash="rv-dept"')
uo=must(uo,"setTimeout(()=>{ logged=true; go('tasks'); },1300); }));","setTimeout(()=>{ logged=true; location.hash='rv-dept'; },1300); }));")
uo=must(uo,"\ngo('auth');\n","\n{ const h=location.hash.slice(1); if(h==='uo-order'||h==='uo-orders'){ logged=true; go(h==='uo-order'?'order':'orders'); } else go('auth'); }\n")
# ================= РОЗГЛЯД =================
rv=open('rozgliad.html').read()
rv=common(rv,'family=Onest:wght@400;500;600;700&display=swap','family=Onest:wght@400;500;600;700&family=Unbounded:wght@600;700&display=swap')
rv=must(rv,'<nav class="mainnav" aria-label="Основна навігація"><a href="#" data-soon>Міські послуги</a><a href="#" data-soon>Часті питання</a></nav>','<nav class="mainnav" aria-label="Основна навігація"><a href="#" data-soon>Міські послуги</a><a href="#" data-soon>Новини</a><a href="#" data-soon>Часті запитання</a></nav>')
rv=rsub(rv,r'<aside class="side uo" aria-label="Меню кабінету">.*?</aside>',side('rv'))
rv=rsub(rv,r'<h1 id="listTitle" style="margin-bottom:20px">Поточні задачі мого відділу</h1>.*?<p class="hint mt" id="empty" hidden>Задач за цим фільтром немає.</p>','<h1 class="ph1" id="listTitle">Поточні задачі мого відділу</h1>\n    <div id="taskGrid"></div>')
rv=rv.replace('Сидоренко М. О.','Петренко О. В.')
rv=must(rv,'Петренко О. В. <small>· Деснянська РДА</small>','Петренко О. В. <small>· уповноважена особа</small>')
rv=must(rv,"\ngo('auth');\n","\n{ const h=location.hash.slice(1); if(h==='rv-dept'||h==='rv-mine'){ mineOnly=h==='rv-mine'; go('list'); } else go('auth'); }\n")
rv=must(rv,'<h1 id="appTitle" style="margin-bottom:12px"></h1>','<h1 class="ph1 sm" id="appTitle"></h1>')
rv=must(rv,'<h1 id="decTitle" style="margin-bottom:16px"></h1>','<h1 class="ph1 sm" id="decTitle"></h1>')
rv=must(rv,'<div class="btns" id="nav" hidden>','<div class="btns bar2" id="nav" hidden>')
rv=must(rv,'м. Київ, просп. Голосіївський, 58, кв. 90','м. Київ, вул. Бальзака, 58, кв. 90')
rv=must(rv,"м. Київ, вул. Липська, 4, кв. 3","м. Київ, Лісовий просп., 4, кв. 3")
rv=rsub(rv,r"function drawList\(\)\{.*?\n\}\n",r'''const recOf=a=>a.rec||(a.no.replace(/^МД-(\d{2})(\d{2})(\d{4})-(\d+)$/,'$1.$2.$3')+' '+['09:12','10:43','11:05','14:20','16:02','18:20'][+a.no.slice(-1)%6]);
function addDays(s,n){ const [dt,tm]=s.split(' '); const [d,m,y]=dt.split('.').map(Number); const t=new Date(y,m-1,d+n); return `${pad(t.getDate())}.${pad(t.getMonth()+1)}.${t.getFullYear()}${tm?' '+tm:''}`; }
let G=null;
function drawList(){
  $('#listTitle').textContent=mineOnly?'Мої задачі':'Поточні задачі мого відділу';
  $('#deptCnt').textContent=APPS.filter(rowHL).length;
  if(G){ G.refresh(); return; }
  G=Grid($('#taskGrid'),{cols:[
    {k:'no',label:'Номер запиту',w:140},{k:'task',label:'Задача',text:()=>'Розгляд заяви',w:120},{k:'proc',label:'Назва процесу',text:a=>a.aid,w:200},
    {k:'ap',label:'Заявник',text:a=>shortName(a.ap.name),w:130},{k:'type',label:'Тип заявника',text:()=>'Фізична особа',w:120},
    {k:'dep',label:'Підрозділ',text:()=>'Управління соціальної та ветеранської політики Деснянської РДА',w:150},
    {k:'exec',label:'Виконавець',w:130},{k:'rec',label:'Дата надходження',text:recOf,date:1,w:140},{k:'due',label:'Кінцева дата',text:a=>addDays(recOf(a),30),date:1,w:140},{k:'dist',label:'Район',text:()=>'Деснянський'},
    {k:'st',label:'Статус',text:a=>ST[a.st][0],hide:1},{k:'ch',label:'Канал подання',text:a=>a.ch==='uo'?'Уповноважена особа':'Портал',hide:1}],
   rows:()=>APPS.filter(a=>!mineOnly||a.exec===ME),rowClass:a=>rowHL(a)?'hl':'',sort:{k:'rec',dir:-1},filters:true,search:true,onRow:a=>openApp(a.no)});
}
''')
rv=rsub(rv,r"\$\$\('\[data-f\]'\)\.forEach.*?\n\$\('#q'\)\.addEventListener\('input',drawList\);\n\$\('#refresh'\)\.addEventListener.*?\n","")
rv=must(rv,"$('#m-dept').classList.toggle('on',v!=='auth'&&!mineOnly); $('#m-mine').classList.toggle('on',v!=='auth'&&mineOnly);","setMenu(v==='auth'?'':(mineOnly?'mine':'dept')); document.querySelector('#v-cab .col').classList.toggle('wide',v==='list');")
rv=rsub(rv,r"function kv\(rows\)\{.*?\nfunction openApp\(no\)\{",r'''function kv(rows){ return `<dl class="irows">${rows.map(([k,v])=>`<div class="irow"><dt>${esc(k)}</dt><dd>${v}</dd></div>`).join('')}</dl>`; }
function blk(title,inner,no){ return `<section class="iblk"><h2 class="iblk-h">${title}</h2><div class="icard">${no?`<p class="icard-no">№${no}</p>`:''}${inner}</div></section>`; }
function infoHTML(a){
  const ap=a.ap, ch=a.ch==='uo'?UO_CH:'Портал послуг, заява підписана КЕП заявника';
  const related=APPS.filter(x=>x!==a&&x.ap.rn===ap.rn);
  const dupRow = dupFlag&&a.st!=='ok'&&a.st!=='rej' ? `<div class="chkrow warn">${BADI}<span>Дублі: знайдено іншу заяву на цей вид допомоги за цією подією — № МД-15102026-233, подана 15.10.2026 через Портал · ${nowS()}</span></div>` : `<div class="chkrow">${OKI}<span>Дублі: інших заяв на цей вид допомоги за цією подією не знайдено · <span class="dupT">${a.dupT||'03.11.2026 о 10:43'}</span></span></div>`;
  const files=(a.files||[['Заява.pdf','03.11.2026, 10:43'],['skany_dokumentiv_1.pdf','03.11.2026, 10:41']]);
  return blk('Відомості про заявника',kv([['Тип заявника','Фізична особа'],['Прізвище, ім\'я та по батькові',esc(ap.name)],['РНОКПП',ap.rn],[ap.doc[0],ap.doc[1]],['Дата народження',ap.bd],['Номер телефону',ap.ph],['Електронна пошта',esc(ap.em)],['Зареєстроване місце проживання',esc(ap.addr)],['Канал подання',esc(ch)]]),a.no)
  + blk('Дані про заяву',kv([['Вид допомоги','<b>'+esc(a.aid)+'</b>'],...a.data.map(([k,v])=>[k,esc(v)]),...(a.kz?[['Комплексна заява',a.kz]]:[])]))
  + (related.length?blk('Пов\'язані заяви заявника',`<ul class="rel">${related.map(r=>`<li><span><a href="#" data-open="${r.no}">№ ${r.no}</a> — ${esc(r.aid)}${r.ch==='portal'?' · подана через Портал':''}</span><span class="st ${ST[r.st][1]}">${ST[r.st][0]}</span></li>`).join('')}</ul>`):'')
  + blk('Перевірки в реєстрах і дублі',a.regs.map(r=>`<div class="chkrow ${r.includes('не знайдено')?'warn':''}">${r.includes('не знайдено')?BADI:OKI}<span>${esc(r)}</span></div>`).join('')+dupRow
     +(['ok','rej'].includes(a.st)?'':'<div style="padding:14px 0 18px"><button type="button" class="chk" id="recheck"><svg aria-hidden="true" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 4v7h-7"/></svg>Перевірити повторно</button></div>'))
  + blk('Надані документи',`<div class="tbl-w" style="margin:4px 0 12px"><table class="files2"><thead><tr><th>Документ</th><th>Дата</th><th style="width:80px">Дії</th></tr></thead><tbody>
    ${files.map(f=>`<tr><td>${esc(f[0])}</td><td>${f[1]}</td><td><button type="button" class="ic2" data-file="${esc(f[0])}" aria-label="Переглянути ${esc(f[0])}">${EYE}</button><button type="button" class="ic2" data-file="${esc(f[0])}" aria-label="Завантажити ${esc(f[0])}">${DL}</button></td></tr>`).join('')}
    </tbody></table></div>${a.ch==='uo'?`<h3 style="font-size:14px;margin:8px 0 4px">Прийняті уповноваженою особою в оригіналі</h3><ul class="rel" style="margin-bottom:14px">${a.docs.map(d=>`<li><span>${esc(d)}</span><span class="off">Прийнято офлайн</span></li>`).join('')}</ul>`:''}`)
  + (a.decision?decisionCard(a.decision,a):'');
}
function decisionCard(d,a){
  const rows=[['Рішення',`<span class="st ${ST[d.dec][1]}">${d.dec==='rework'?'На доопрацювання':ST[d.dec][0]}</span>`]];
  if(d.dec==='ok') rows.push(['Сума, грн',d.amt?fmtN(d.amt)+(d.amt!==d.pre?` (передбачено ${fmtN(d.pre)})`:''):a.sum],['Підстава',esc(a.basis)]);
  if(d.amtWhy) rows.push(['Причина зміни суми',esc(d.amtWhy)]);
  if(d.why) rows.push(['Причина відмови',esc(d.why)]);
  if(d.docs) rows.push(['Документи для доопрацювання',esc(d.docs.join('; '))]);
  rows.push(['Коментар',esc(d.com||'—')],['Дата і виконавець',`${d.date}, ${esc(d.by)}`]);
  return blk('Рішення щодо заяви',kv(rows)+'<div style="padding:14px 0 18px"><button type="button" class="btn o" data-file="Рішення.pdf">Переглянути рішення (PDF)</button></div>');
}
function openApp(no){''')

rv=must(rv,'<div class="ro"><span>Сума, грн</span><b id="okSum"></b></div>','''<div class="fld" data-req data-pat="^[1-9][0-9]{2,6}$" data-err="Вкажіть суму цілим числом у гривнях"><label for="okSum" id="okSumL">Сума допомоги, грн *</label><input id="okSum" type="text" inputmode="numeric" autocomplete="off"><span class="hint" id="okSumHint"></span></div>
        <div class="msg warn" id="okSumWarn" hidden><span class="ic" aria-hidden="true">☝</span><span id="okSumWarnT"></span></div>
        <div class="fld" id="okWhyF" data-req data-err="Зазначте, чому змінено суму" hidden><label for="okWhy">Причина зміни суми *</label><input id="okWhy" type="text" placeholder="Наприклад: за довідкою медичного закладу ушкодження легкі"></div>''')
rv=must(rv,"$('#okSum').textContent=cur.sum; $('#okIban').textContent=cur.ap.iban;","const pr=preset(cur); cur._pre=pr[0]; $('#okSum').value=fmtN(pr[0]); $('#okSumHint').textContent=pr[1]+': '+fmtN(pr[0])+' грн. За потреби змініть суму.'; $('#okSumL').textContent=(cur.short.startsWith('Щомісячна')?'Сума щомісячної допомоги, грн *':'Сума допомоги, грн *'); $('#okWhy').value=''; amtCheck(); $('#okIban').textContent=cur.ap.iban;")
rv=must(rv,"['Сума, грн',a.sum],['Рахунок для виплати (IBAN)',ap.iban]","['Сума, грн',fmtN(amtVal())+(amtVal()!==cur._pre?` (передбачено ${fmtN(cur._pre)})`:'')],...(amtVal()!==cur._pre?[['Причина зміни суми',$('#okWhy').value]]:[]),['Рахунок для виплати (IBAN)',ap.iban]")
rv=must(rv,"cur._dec={dec:d,why:$('#rejWhy').value,","cur._dec={dec:d,amt:d==='ok'?amtVal():0,pre:cur._pre,amtWhy:d==='ok'&&amtVal()!==cur._pre?$('#okWhy').value:'',why:$('#rejWhy').value,")
rv=must(rv,"function showResult(){",r"""const INJ_SUM={'Легкі':10000,'Середньої тяжкості':20000,'Тяжкі':30000}, DEATH_SUM=40000;
const fmtN=n=>String(n).replace(/\B(?=(\d{3})+(?!\d))/g,' ');
function preset(a){
  const deg=(a.data.find(d=>d[0]==='Ступінь тяжкості')||[])[1];
  if(a.short==='Поранення') return [INJ_SUM[deg]||INJ_SUM['Легкі'],'Передбачено для ступеня тяжкості «'+String(deg||'—').toLowerCase()+'»'];
  if(a.short==='Загибель') return [DEATH_SUM,'Передбачено для членів сім\'ї загиблої особи'];
  return [+String(a.sum).replace(/\D/g,''),'Передбачено для цього виду допомоги'];
}
const amtVal=()=>+($('#okSum').value.replace(/\D/g,'')||0);
function amtCheck(){ const ch=amtVal()!==cur._pre&&$('#okSum').value.trim()!=='';
  $('#okSumWarn').hidden=!ch; $('#okWhyF').hidden=!ch;
  if(ch) $('#okSumWarnT').textContent=`Сума відрізняється від передбаченої (${fmtN(cur._pre)} грн). Зазначте причину зміни — вона потрапить у рішення.`; }
document.addEventListener('input',e=>{ if(e.target.id==='okSum'){ const v=e.target.value.replace(/\D/g,'').slice(0,7); e.target.value=fmtN(v); amtCheck(); } });
function showResult(){""")
# --- Нова назва послуги
SVC='Матеріальна допомога постраждалим в результаті обстрілів, спричинених збройною агресією Російської Федерації проти України'
TAIL='постраждалим в результаті обстрілів, спричинених збройною агресією Російської Федерації проти України'
def ren(x):
    for a,b2 in [('Матеріальна допомога особам, що опинились в складних життєвих обставинах внаслідок обстрілів, спричинених збройною агресією російської федерації',SVC),
                 ('Матеріальна допомога особам, що опинились в складних життєвих обставинах внаслідок обстрілів',SVC),
                 ('Матеріальна допомога особам у складних життєвих обставинах через обстріли',SVC),
                 ('матеріальну допомогу особам у складних життєвих обставинах через обстріли','матеріальну допомогу '+TAIL),
                 ('матеріальної допомоги особам у складних життєвих обставинах через обстріли','матеріальної допомоги '+TAIL),
                 ('Матеріальна допомога через обстріли',SVC),
                 ('матеріальну допомогу через обстріли','матеріальну допомогу '+TAIL)]:
        x=x.replace(a,b2)
    assert 'складних життєвих' not in x and 'через обстріли' not in x, 'old name left'
    return x
cit,uo,rv=ren(cit),ren(uo),ren(rv)
for _n in ('uo','rv'):
    globals()[_n]=re.sub(r'(<details class="demo">.*?<div class="b">\s*<p class="n">[^<]*</p>\s*)', lambda m:m.group(1)+INTRO_BTN, globals()[_n], count=1, flags=re.S)
    assert 'data-proto="intro"' in globals()[_n]

# ================= ЗБІРКА =================
wrap=lambda s:'<!doctype html>\n<html lang="uk">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n</head>\n<body>\n'+s+'\n</body>\n</html>\n'
b64=lambda s:base64.b64encode(wrap(s).encode()).decode()
def mkloader(dflt=''):
  return f'''<script>
(function(){{
  var P={{uo:"{b64(uo)}",rv:"{b64(rv)}"}};
  var D="{dflt}"; if(D&&!location.hash.slice(1)){{ try{{ history.replaceState(null,'','#'+D); }}catch(e){{}} }}
  var h=(location.hash.slice(1)||D).split('-')[0];
  if(P[h]){{ document.documentElement.style.visibility='hidden'; window.addEventListener('DOMContentLoaded',function(){{ var t=new TextDecoder().decode(Uint8Array.from(atob(P[h]),function(c){{return c.charCodeAt(0)}})); document.open(); document.write(t); document.close(); document.documentElement.style.visibility=''; }}); }}
}})();
</script>
'''
full=cit+'\n'+mkloader()
J=lambda n:os.path.join(OUT,n)
open(J('index.html'),'w').write(wrap(full))                      # GitHub Pages: презентація + усі ролі
open(J('artifact_zayavnyk.html'),'w').write(full)                 # макети в чаті Claude
open(J('artifact_uo.html'),'w').write(cit+'\n'+mkloader('uo'))
open(J('artifact_rozgliad.html'),'w').write(cit+'\n'+mkloader('rv-dept'))
print('Зібрано:', J('index.html'), round(len(full)/1024),'КБ')
